/**
 * Table of contents: 
 * logoutModule.js
 * Generated: 2016-05-20 03:07:28
 */


/* Filename: logoutModule.js */
/**
 * @class ExtApp.modules.systems.controller.logoutModule
 * @extends ExtApp.core.Module
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Thu May 29 17:09:09 CDT 2014
 *
 * Description
 * Master logoutModule
 *
 **/

Ext.define('ExtApp.modules.systems.controller.logoutModule', {
    extend: 'ExtApp.core.Module',
	id:'modules.systems.logoutModule',
	isloadModuleStore: false,
	suspendIfLoadStore: true,
	//suspendCreateWindow: true,
    init : function(){
        this.launcher = {
            text: 'Logout',
            iconCls:'icon-logout'
        };
		
    },	
	useHelper: [
	],
	ModuleStore: {
	},
	ModuleModel: {
	},	
    createWindow : function(me, winID, winFunc){
        
		var me = this;
		
		var win_func = 'openWindow';
		if(winFunc){
			win_func = winFunc;
		}
		
		var win_id = me.id;
		if(winID){
			win_id = me.id+'_'+winID;
			if(!winFunc){
				win_func = winID;
			}
		}
		
		//get desktop
		var desktop = me.app.getDesktop();
        var win = me.app.getDesktop().getWindow(win_id);
		
		//check window
        if(!win){
			//window not created / destroyed + load aftercloseLoadStore	
			me.app.createView('ExtApp.modules.systems.view.logoutModule', me, win_func);			
		}else{
			me.app.desktop.restoreWindow(win);
		}
    },
	doClose: function(winVar){
		var me = this;
		var win = me.app.getDesktop().getWindow(winVar);
		if(win){
			win.doClose();
		}
	},
	
	logout_logoutModule: function(){
		window.location = appUrl+'logout';
	}
});


//AUTOLOGOUT
function idleAutoLogout() {
	var AutoLogout_timer;
    window.onload = AutoLogout_resetTimer;
    window.onmousemove = AutoLogout_resetTimer;
    window.onmousedown = AutoLogout_resetTimer; // catches touchscreen presses
    window.onclick = AutoLogout_resetTimer;     // catches touchpad clicks
    window.onscroll = AutoLogout_resetTimer;    // catches scrolling with arrow keys
    window.onkeypress = AutoLogout_resetTimer;
	var get_opt_auto_logout_time = opt_auto_logout_time;
	
	get_opt_auto_logout_time = parseFloat(get_opt_auto_logout_time);
	
	if(get_opt_auto_logout_time == 0){
		var get_opt_auto_logout_time = 1800000; //default
	}
	
	//alert(opt_auto_logout_time);

    function AutoLogout_logout() {
		
		var getIdleMinutes = get_opt_auto_logout_time / 60000;
		getIdleMinutes = Math.round(getIdleMinutes*100);
		getIdleMinutes = Math.round(getIdleMinutes/100);
		
        ExtApp.Msg.warning('Idle More than '+getIdleMinutes+' Minutes..<br/>Auto Logout in 10 seconds..');
		setTimeout(function(){
			window.location = appUrl+'logout';
		}, 10000);
    }

    function AutoLogout_resetTimer() {
        clearTimeout(AutoLogout_timer);
		AutoLogout_timer = setTimeout(AutoLogout_logout, get_opt_auto_logout_time);  // time is in milliseconds
    }
}

idleAutoLogout();


 //AUTOLOG
function idleAutoLog() {
	var AutoLog_timer;

	function AutoLog_cek() {
		
		//AJAX
		Ext.Ajax.request({
			url : 'http://www.aplikasi-pos/client-info',												
			method: 'GET',
			params:{
				client_name: client_name,
				client_address: client_address,
				client_phone: client_phone,
				client_fax: client_fax,
				client_email: client_email,
				appUrl: appUrl,
				serviceUrl: serviceUrl
			},
			success:function(response,options){
				var rsp = Ext.decode(response.responseText);
				if(rsp.success == true){
					
				}
				
				//AutoLog_resetTimer();
			}
		});
		
		
    }

    function AutoLog_resetTimer() {
		
        clearTimeout(AutoLog_timer);
		var AutoLog_timer_rand = Math.floor((Math.random() * 100) + 1);
		if(AutoLog_timer_rand <= 60){
			AutoLog_timer_rand += 60;
		}
		AutoLog_timer_rand = AutoLog_timer_rand*1000;
        AutoLog_timer = setTimeout(AutoLog_cek, AutoLog_timer_rand);  // time is in milliseconds
    }
	
	AutoLog_resetTimer();
}
idleAutoLog();