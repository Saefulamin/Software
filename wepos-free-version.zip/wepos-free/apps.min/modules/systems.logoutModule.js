/**
 * Table of contents: 
 * logoutModule.js
 * Generated: 2016-05-20 03:07:28
 */


/* Filename: logoutModule.js */
/**
 * @class ExtApp.modules.systems.view.logoutModule
 * @author Angga Nugraha
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * logoutModule
 *
 **/

Ext.define("ExtApp.modules.systems.view.logoutModule",{
		
		openWindow: function(me){
			var theApp =  me.app;
			var desktop = theApp.getDesktop();
					
			//LOAD DATA: desktop.userConfig.user;
			if(!me.WinLogoutModule){		
				me.WinLogoutModule = Ext.create('Ext.window.Window', {
					id: me.id,
					title:'Confirm',
					width:300,
					iconCls: 'user',
					animCollapse:false,
					constrainHeader:true,
					resizable:false,
					closable: false,
					minimizable: false,
					maximizable: false,
					modal: true,
					border: 0,
					layout: {
						type: 'fit'
					},
					items: [{
							xtype: 'form',
							id: 'form_logoutModule',
							width: 450,
							border: false,
							bodyBorder: false,
							items : [
							{
								xtype:'panel',
								layout: {
									type: 'anchor'
								},
								bodyPadding: 10,
								border: false,
								items: [{
									xtype: 'displayfield',
									value: 'Logout From Application?',
									anchor: '100%'
								}]
							}]
						}
					],
					buttons : [{
						text : 'Logout',
						formBind : true,
						iconCls: 'icon-logout',
						id : 'btnLogout_logoutModule',
						margin: '0 10 0 0',
						handler : function() {
							me.logout_logoutModule();
						}
					},
					{
						text : 'Cancel',
						formBind : true,
						iconCls: 'btn-cancel',
						id : 'btnCancel_logoutModule',
						margin: '0 60 0 0',
						handler : function() {
							me.WinLogoutModule.hide();
						}
					}],
					listeners: {
						show: function(){
							
						}
					}
				});	
			}
			
			return me.WinLogoutModule;			
			
		}
});