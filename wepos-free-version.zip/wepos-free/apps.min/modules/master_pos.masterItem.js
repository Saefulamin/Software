/**
 * Table of contents: 
 * model_masterItem.js
 * model_masterUnit.js
 * model_masterSupplier.js
 * model_itemCategory.js
 * store_masterItem.js
 * store_itemGroup.js
 * store_masterUnit.js
 * store_masterSupplier.js
 * store_itemCategory.js
 * masterItem.js
 * Generated: 2016-09-09 02:17:29
 */


/* Filename: model_masterItem.js */
/**
 * @class ExtApp.modules.master_pos.model.model_masterItem
 * @extends Ext.data.Model
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Sat July 19 17:09:09 CDT 2014
 *
 * Description
 * Model masterItem
 *
 **/

Ext.define('ExtApp.modules.master_pos.model.model_masterItem', {
	extend : 'Ext.data.Model',
	alias : 'model_masterItem',
	fields : [
				{name : 'id', type : 'int'}, 
				{name : 'item_name', type : 'string'}, 
				{name : 'item_desc', type : 'string'}, 
				{name : 'item_manufacturer', type : 'string'}, 
				{name : 'item_price', type : 'string'}, 
				{name : 'item_price_show', type : 'string'}, 
				{name : 'item_hpp', type : 'string'}, 
				{name : 'item_hpp_show', type : 'string'}, 
				{name : 'last_in', type : 'string'}, 
				{name : 'last_in_show', type : 'string'}, 
				{name : 'total_qty_stok', type : 'string'}, 
				{name : 'item_type', type : 'string'}, 
				{name : 'item_type_name', type : 'string'}, 
				{name : 'item_image', type : 'string'}, 
				{name : 'item_image_show', type : 'string'}, 
				{name : 'item_image_src', type : 'string'}, 
				{name : 'category_id', type : 'int'}, 
				{name : 'item_category_name', type : 'string'}, 
				{name : 'unit_id', type : 'int'}, 
				{name : 'unit_name', type : 'string'}, 
				{name : 'supplier_id', type : 'int'}, 
				{name : 'supplier_name', type : 'string'}, 
				{name : 'is_active', type : 'int'},
				{name : 'is_active_text', type : 'string'}
			],
	proxy : {
		type : 'ajax',
		url : serviceUrl,
		extraParams:{
			module: 'master_pos',
			file: 'masterItem',
			action: 'gridData'
		},
		actionMethods : {
			read : 'POST'
		},
		reader : {
			type : 'json',
			root : 'data',
			idProperty : 'id',
			totalProperty : 'totalCount'
		}
	}
});




/* Filename: model_masterUnit.js */
/**
 * @class ExtApp.modules.master_pos.model.model_masterUnit
 * @extends Ext.data.Model
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Sat July 19 17:09:09 CDT 2014
 *
 * Description
 * Model masterUnit
 *
 **/

Ext.define('ExtApp.modules.master_pos.model.model_masterUnit', {
	extend : 'Ext.data.Model',
	alias : 'model_masterUnit',
	fields : [
				{name : 'id', type : 'int'},  
				{name : 'unit_name', type : 'string'}, 
				{name : 'unit_code', type : 'string'}, 
				{name : 'is_active', type : 'int'},
				{name : 'is_active_text', type : 'string'}
			],
	proxy : {
		type : 'ajax',
		url : serviceUrl,
		extraParams:{
			module: 'master_pos',
			file: 'masterUnit',
			action: 'gridData'
		},
		actionMethods : {
			read : 'POST'
		},
		reader : {
			type : 'json',
			root : 'data',
			idProperty : 'id',
			totalProperty : 'totalCount'
		}
	}
});




/* Filename: model_masterSupplier.js */
/**
 * @class ExtApp.modules.master_pos.model.model_masterSupplier
 * @extends Ext.data.Model
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Sat July 19 17:09:09 CDT 2014
 *
 * Description
 * Model masterSupplier
 *
 **/

Ext.define('ExtApp.modules.master_pos.model.model_masterSupplier', {
	extend : 'Ext.data.Model',
	alias : 'model_masterSupplier',
	fields : [
				{name : 'id', type : 'int'},  
				{name : 'supplier_code', type : 'string'}, 
				{name : 'supplier_name', type : 'string'}, 
				{name : 'supplier_contact_person', type : 'string'}, 
				{name : 'supplier_address', type : 'string'}, 
				{name : 'supplier_phone', type : 'string'}, 
				{name : 'supplier_fax', type : 'string'}, 
				{name : 'supplier_email', type : 'string'}, 
				{name : 'is_active', type : 'int'},
				{name : 'is_active_text', type : 'string'}
			],
	proxy : {
		type : 'ajax',
		url : serviceUrl,
		extraParams:{
			module: 'master_pos',
			file: 'masterSupplier',
			action: 'gridData'
		},
		actionMethods : {
			read : 'POST'
		},
		reader : {
			type : 'json',
			root : 'data',
			idProperty : 'id',
			totalProperty : 'totalCount'
		}
	}
});


/* Filename: model_itemCategory.js */
/**
 * @class ExtApp.modules.master_pos.model.model_itemCategory
 * @extends Ext.data.Model
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Thu May 29 17:09:09 CDT 2014
 *
 * Description
 * Model itemCategory
 *
 **/

Ext.define('ExtApp.modules.master_pos.model.model_itemCategory', {
	extend : 'Ext.data.Model',
	alias : 'model_itemCategory',
	fields : [
				{name : 'id', type : 'int'}, 
				{name : 'item_category_name', type : 'string'}, 
				{name : 'item_category_code', type : 'string'}, 
				{name : 'item_category_desc', type : 'string'}, 
				{name : 'is_active', type : 'int'},
				{name : 'is_active_text', type : 'string'}
			],
	proxy : {
		type : 'ajax',
		url : serviceUrl,
		extraParams:{
			module: 'master_pos',
			file: 'itemCategory',
			action: 'gridData'
		},
		actionMethods : {
			read : 'POST'
		},
		reader : {
			type : 'json',
			root : 'data',
			idProperty : 'id',
			totalProperty : 'totalCount'
		}
	}
});




/* Filename: store_masterItem.js */
/**
 * @class ExtApp.modules.master_pos.store.store_masterItem
 * @extends Ext.data.Store
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * Store masterItem
 *
 **/
 
Ext.define('ExtApp.modules.master_pos.store.store_masterItem', {
	extend : 'Ext.data.Store',
	model : 'ExtApp.modules.master_pos.model.model_masterItem',
	autoLoad : false,
	remoteSort: true
});
 

/* Filename: store_itemGroup.js */
/**
 * @class ExtApp.modules.master_pos.store.store_itemGroup
 * @extends Ext.data.Store
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * store_itemGroup
 *
 **/
Ext.define('ExtApp.modules.master_pos.store.store_itemGroup', {
	extend : 'Ext.data.Store',
	fields: ['val', 'name'],
    data : [
        {"val":"main", "name":"Bahan Baku"},
        {"val":"support", "name":"Bahan Pendukung"}
    ],
	autoLoad : false
});


/* Filename: store_masterUnit.js */
/**
 * @class ExtApp.modules.master_pos.store.store_masterUnit
 * @extends Ext.data.Store
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * Store masterUnit
 *
 **/
 
Ext.define('ExtApp.modules.master_pos.store.store_masterUnit', {
	extend : 'Ext.data.Store',
	model : 'ExtApp.modules.master_pos.model.model_masterUnit',
	autoLoad : false,
	remoteSort: true
});
 

/* Filename: store_masterSupplier.js */
/**
 * @class ExtApp.modules.master_pos.store.store_masterSupplier
 * @extends Ext.data.Store
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * Store masterSupplier
 *
 **/
 
Ext.define('ExtApp.modules.master_pos.store.store_masterSupplier', {
	extend : 'Ext.data.Store',
	model : 'ExtApp.modules.master_pos.model.model_masterSupplier',
	autoLoad : false,
	remoteSort: true
});
 

/* Filename: store_itemCategory.js */
/**
 * @class ExtApp.modules.master_pos.store.store_itemCategory
 * @extends Ext.data.Store
 * requires 
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * Store itemCategory
 *
 **/
 
Ext.define('ExtApp.modules.master_pos.store.store_itemCategory', {
	extend : 'Ext.data.Store',
	model : 'ExtApp.modules.master_pos.model.model_itemCategory',
	autoLoad : false,
	remoteSort: true
});
 

/* Filename: masterItem.js */
/**
 * @class ExtApp.modules.master_pos.view.masterItem
 * @author Angga Nugraha
 * @date Mon Jul 25 23:27:57 CDT 2011
 *
 * Description
 * View masterItem
 *
 **/

Ext.define("ExtApp.modules.master_pos.view.masterItem",{
		
		openWindow: function(me){
			var theApp =  me.app;
			var desktop = theApp.getDesktop();
					
			//LOAD MODEL AND STORE
			var store_masterItem = theApp.getStore('master_pos.store_masterItem');	
			var helperGrid = theApp.getHelper('Grid');
			
			var store_ComboboxMasterUnit = theApp.getStore('store_ComboboxMasterUnit', false);			
			if(store_ComboboxMasterUnit == false){
				store_ComboboxMasterUnit = theApp.copyStore('master_pos','store_masterUnit','store_ComboboxMasterUnit');
			}
			store_ComboboxMasterUnit.proxy.extraParams.limit = 99999;
			
			/*
			var store_ComboboxMasterSupplier = theApp.getStore('store_ComboboxMasterSupplier', false);			
			if(store_ComboboxMasterSupplier == false){
				store_ComboboxMasterSupplier = theApp.copyStore('master_pos','store_masterSupplier','store_ComboboxMasterSupplier');
			}
			store_ComboboxMasterSupplier.proxy.extraParams.limit = 99999;
			*/
			
			var store_ComboboxItemGroup = theApp.getStore('store_ComboboxItemGroup', false);			
			if(store_ComboboxItemGroup == false){
				store_ComboboxItemGroup = theApp.copyStore('master_pos','store_itemGroup','store_ComboboxItemGroup');
			}
			store_ComboboxItemGroup.proxy.extraParams.limit = 99999;
			
			var selModel_masterItem = Ext.create('Ext.selection.CheckboxModel', {
				listeners: {
					selectionchange: function(sm, selections) {
						Ext.getCmp('grid_masterItem').down('#deleteButton_masterItem').setDisabled(selections.length == 0);
					}
				}
			});
			
			//createWindow is from core
			return desktop.createWindow({
				id: me.id,
				title:'Master Items',
				width:850,
				height:500,
				iconCls: 'icon-grid',
				animCollapse:false,
				constrainHeader:true,
				resizable:true,
				maximized: false,
				border: 0,
				layout: {
					type: 'fit'
				},
				items: [
					{
						xtype: 'gridpanel',
						margins: '0 0 0 0',
						region: 'center',
						store: store_masterItem,
						id: 'grid_masterItem',
						scroll: true,
						selModel: selModel_masterItem,	
						columns: [
							{xtype: 'gridcolumn', dataIndex: 'id', text: 'ID', hidden: true, hideable: false},
							{xtype: 'gridcolumn', dataIndex: 'item_name', text: 'Name', width: 200},
							{xtype: 'gridcolumn', dataIndex: 'item_type_name', text: 'Type', width: 150},
							{xtype: 'gridcolumn', dataIndex: 'unit_name', text: 'Unit', width: 100},
							{xtype: 'gridcolumn', dataIndex: 'item_category_name', text: 'Category', width: 100},
							{xtype: 'gridcolumn', dataIndex: 'item_price_show', text: 'Unit Price', width: 120, align:'right'},
							{xtype: 'gridcolumn', dataIndex: 'item_hpp_show', text: 'HPP', width: 120, align:'right'},
							{xtype: 'gridcolumn', dataIndex: 'item_desc', text: 'Description', width: 120},
							{xtype: 'gridcolumn', dataIndex: 'is_active_text',text: 'Status Active', width: 100}
						],
						viewConfig: {
							stripeRows: true,
							forceFit: true
						},
						listeners: {
							itemdblclick: function(view,rec,item,index,eventObj){
								
								var getSelection = Ext.getCmp('grid_masterItem').getSelectionModel().selected;
								if(getSelection.length > 0){
									me.formType = 'edit';
									me.edit_data = rec.data;
									me.createWindow(me,'add_masterItem');
								}
							}
						},
						bbar : helperGrid.paging({ds : store_masterItem, title : 'Items'}),
						dockedItems: [{
							xtype: 'toolbar',
							dock: 'top',
							items: [
							{
								xtype: 'textfield',
								name: 'keywords',
								id:'keywords_masterItem',
								width:200,
								labelSeparator: '',
								emptyText: 'Keywords: Name / Supplier',
								anchor: '100%',	
								listeners: {
									specialkey: function(field, e){									
										//Keypress enter
										if (e.getKey() == e.ENTER) {
											me.search_masterItem();
										}
									}
								}
							},	
							{
								xtype: 'button',
								text: 'Search',
								itemId: 'btnFilterSearch_masterItem',
								tooltip:'Search',
								iconCls:'btn-search',
								handler: function(){											
									me.search_masterItem();	
								}
							},	
							{
								xtype: 'button',
								text: 'Reset',
								itemId: 'btnResetFilterSearch_masterItem',
								tooltip:'Reset',
								iconCls:'btn-reset',
								handler: function(){											
									me.search_masterItem(true);	
								}
							},
							'->',
							{
								text:'Add',
								itemId: 'addButton_masterItem',
								tooltip:'Add Items',
								iconCls:'btn-add',
								handler: function(){
									me.formType = 'add';
									me.createWindow(me,'add_masterItem');
								}
								
							}, 
							'-',
							{
								text:'Delete',
								itemId: 'deleteButton_masterItem',
								tooltip:'Delete Items',
								iconCls:'btn-delete',
								disabled: true,
								handler: function(){
									var getSelection = Ext.getCmp('grid_masterItem').getSelectionModel().selected;
									if(getSelection.length > 0){
										me.delete_data = getSelection.items[0].data;
										me.deleteConfirm_masterItem();
									}else{
										ExtApp.Msg.info('Please Select Items!');
									}
								}
							},
							'-',
							{
								text:'Refresh',
								itemId: 'refreshButton_masterItem',
								tooltip:'Refresh Items',
								iconCls:'btn-refresh',
								handler: function(){
									Ext.getCmp('grid_masterItem').store.load();
								}
								
							}]
						}]
					}
				],
				listeners: {
					boxready: function(){
						
						//this.maximize();					
						//store_masterItem.load();			
						store_ComboboxMasterUnit.load();			
						//store_ComboboxMasterSupplier.load();			
						store_ComboboxItemGroup.load();
						
					},
					show: function(){
						me.search_masterItem(true); //reset true
					}
				}
			});		
			
		},
		
		add_masterItem : function(me){
			var theApp =  me.app;
			var desktop = theApp.getDesktop();
			var Titletext = 'Add New ';
			if(me.formType == 'edit'){
				Titletext = 'Update ';
			}
			
			var store_ComboboxItemCategory = theApp.getStore('store_ComboboxItemCategory', false);			
			if(store_ComboboxItemCategory == false){
				store_ComboboxItemCategory = theApp.copyStore('master_pos','store_itemCategory','store_ComboboxItemCategory');
			}
			
			var store_ComboboxMasterUnit = theApp.getStore('store_ComboboxMasterUnit', false);			
			if(store_ComboboxMasterUnit == false){
				store_ComboboxMasterUnit = theApp.copyStore('master_pos','store_masterUnit','store_ComboboxMasterUnit');
			}
			
			//var store_ComboboxMasterSupplier = theApp.getStore('store_ComboboxMasterSupplier', false);			
			//if(store_ComboboxMasterSupplier == false){
			//	store_ComboboxMasterSupplier = theApp.copyStore('master_pos','store_masterSupplier','store_ComboboxMasterSupplier');
			//}
			
			var store_ComboboxItemGroup = theApp.getStore('store_ComboboxItemGroup', false);			
			if(store_ComboboxItemGroup == false){
				store_ComboboxItemGroup = theApp.copyStore('master_pos','store_itemGroup','store_ComboboxItemGroup');
			}

			//createWindow is from core
			return desktop.createWindow({
				id: me.id+'_add_masterItem',
				title: Titletext,
				width:650,
				height:480,
				iconCls: 'btn-add',
				animCollapse:false,
				constrainHeader:true,
				resizable:false,
				minimizable: false,
				maximizable: false,
				modal: true,
				border: 0,
				layout: {
					type: 'fit'
				},				
				items:[
					{
						xtype: 'form',
						id:	'form_masterItem',
						border: 0,
						layout: {
							type: 'border'
						},
						items:[
						{
							xtype: 'panel',
							flex: 1,
							region: 'center',
							layout: {
								type: 'auto'
							},	          					       
							border: 0,          
							bodyPadding: 10,
							margin: '0 5 0 0',
							defaults: {
								margin: '5 0 0 0',
								width: 300
							},
							items: [
								{
									xtype: 'hidden', 
									name: 'form_type_masterItem',
									value: me.formType
								},
								{
									xtype: 'hidden',
									name: 'id'
								},
								{
									xtype: 'hidden',
									name: 'item_image'
								},
								{
									xtype: 'textfield',
									name: 'item_name',
									fieldLabel: 'Item Name',
									anchor: '100%',
									labelWidth: 80,
									allowBlank: false
								},													
								{
									xtype: 'hidden',
									name: 'item_type'
								},
								{
									xtype: 'hidden',
									name: 'unit_id'
								},
								{
									xtype: 'hidden',
									name: 'category_id'
								},
								{
									xtype: 'combobox',
									name: 'item_type_name',
									fieldLabel: 'Type',
									emptyText: '-Select-',
									width: 250,
									labelWidth: 80,
									store: store_ComboboxItemGroup,										
									displayField: 'name',
									valueField: 'val',
									queryMode: 'local',										
									allowBlank: false,
									listeners:{
										select: function(combo, records, eOpts){
											var form2 = Ext.getCmp('form_masterItem').getForm();	
											form2.findField('item_type').setValue(records[0].data.val);
											form2.findField('item_type_name').setValue(records[0].data.name);
										}
									}
								},
								{
									xtype: 'combobox',
									name: 'item_category_name',
									fieldLabel: 'Category',
									emptyText: '-Select-',
									width: 250,
									labelWidth: 80,
									store: store_ComboboxItemCategory,										
									displayField: 'item_category_name',
									valueField: 'id',
									queryMode: 'local',										
									allowBlank: false,
									listeners:{
										select: function(combo, records, eOpts){
											var form2 = Ext.getCmp('form_masterItem').getForm();	
											form2.findField('category_id').setValue(records[0].data.id);
											form2.findField('item_category_name').setValue(records[0].data.item_category_name);
										}
									}
								},
								{
									xtype: 'combobox',
									name: 'unit_name',
									fieldLabel: 'Unit',
									emptyText: '-Select-',
									width: 250,
									labelWidth: 80,
									store: store_ComboboxMasterUnit,										
									displayField: 'unit_name',
									valueField: 'id',
									queryMode: 'local',										
									allowBlank: false,
									listeners:{
										select: function(combo, records, eOpts){
											var form2 = Ext.getCmp('form_masterItem').getForm();	
											form2.findField('unit_id').setValue(records[0].data.id);
											form2.findField('unit_name').setValue(records[0].data.unit_name);
										}
									}
								},
								{
									xtype: 'numberfield',
									name: 'item_price',
									fieldLabel: 'Unit Price',
									width: 250,
									labelWidth: 80,
									minValue: 0,
									margin: '5 0 5 0',
									allowDecimals: true,
									allowBlank: false,
									hideTrigger: true,
									keyNavEnabled: false,
									mouseWheelEnabled: false
								},
								{
									xtype: 'numberfield',
									name: 'item_hpp',
									fieldLabel: 'HPP',
									width: 250,
									labelWidth: 80,
									minValue: 0,
									margin: '5 0 5 0',
									allowDecimals: true,
									allowBlank: false,
									hideTrigger: true,
									keyNavEnabled: false,
									mouseWheelEnabled: false
								},
								{
									xtype: 'hidden',
									name: 'supplier_id'
								},
								/*{
									xtype: 'combobox',
									name: 'supplier_name',
									fieldLabel: 'Supplier',
									emptyText: '-Select-',
									anchor: '100%',
									labelWidth: 80,
									store: store_ComboboxMasterSupplier,										
									displayField: 'supplier_name',
									valueField: 'id',
									queryMode: 'local',										
									allowBlank: false,
									listeners:{
										select: function(combo, records, eOpts){
											var form2 = Ext.getCmp('form_masterItem').getForm();	
											form2.findField('supplier_id').setValue(records[0].data.id);
											form2.findField('supplier_name').setValue(records[0].data.supplier_name);
										}
									}
								},*/
								/*{
									xtype: 'numberfield',
									name: 'item_hpp',
									fieldLabel: 'HPP',
									width: 250,
									minValue: 0,
									margin: '5 0 5 0',
									allowDecimals: true,
									allowBlank: false,
									hideTrigger: true,
									keyNavEnabled: false,
									mouseWheelEnabled: false
								},
								{
									xtype: 'textfield',
									name: 'item_manufacturer',
									fieldLabel: 'Manufacturer',
									anchor: '100%',
									allowBlank: true,
									margin: '5 0 5 0'
								},*/
								{
									xtype: 'checkbox',
									name: 'is_active',
									labelWidth: 85,
									fieldLabel: 'Status Active',
									inputValue: '1',
									margin: '0 0 10 0'
								},
								{
									xtype: 'displayfield',
									value: 'Description'
								},
								{
									xtype: 'htmleditor',
									name: 'item_desc',
									anchor: '100%',
									height: 150,
									enableColors: false,
									enableAlignments: false,
									enableFont: false,
									enableFontSize: false,
									enableFormat: true,
									enableLinks: false,
									enableLists: false,
									enableSourceEdit: false,
									margin: '0 0 10 0'
								}
								
							]	
						},
						{
							xtype: 'panel',
							flex: 1,
							region: 'east',
							layout: {
								type: 'auto'
							},							       
							border: 0,
							bodyPadding: 10,
							items: [
								{
									xtype: 'displayfield',
									value: 'Product Image'
								},
								{
									xtype: 'filefield',
									name: 'upload_image',
									emptyText: 'Upload Image, Size Image min 640 (pixel)',
									msgTarget: 'side',
									width: 300,
									buttonText: '',
									buttonConfig: {
										iconCls: 'btn-upload'
									}
								},
								{
									xtype: 'image',
									id: 'item_image_src',
									name: 'item_image_src',
									autoEl: 'div',
									margin: '5 0 5 0'
								}							
								
							]
						
						}
						]
					}
				],
				buttons : [{
					text : 'Save',
					formBind : true,
					id : 'btnSave_masterItem',
					iconCls:'btn-save',
					handler : function() {
						me.save_masterItem();
					}
				}, {
					text : 'Cancel',					
					iconCls:'btn-cancel',
					handler : function() {
						me.doClose(me.id+'_add_masterItem');
					}
				}],
				listeners: {
					show: function(){
						var form = Ext.getCmp('form_masterItem').getForm();
						
						if(me.formType == 'edit'){
							form.setValues(me.edit_data);	
							if(me.edit_data.item_image != ''){
								Ext.getCmp('item_image_src').setSrc(me.edit_data.item_image_src);
							}
											
						}else{
							form.reset();
							form.findField('is_active').setValue(1);
							form.findField('item_type').setValue('item');
						}							
						
						store_ComboboxItemCategory.load({
							callback: function(){
								if(me.formType == 'edit'){
									form.findField('item_category_name').select(me.edit_data.category_id);
								}
							}
						});					
						
						store_ComboboxMasterUnit.load({
							callback: function(){
								if(me.formType == 'edit'){
									form.findField('unit_name').select(me.edit_data.unit_id);
								}
							}
						});
						
						/*store_ComboboxMasterSupplier.load({
							callback: function(){
								if(me.formType == 'edit'){
									form.findField('supplier_name').select(me.edit_data.supplier_id);								
								}
							}
						});*/
					}
				}
			});
		}
		
});