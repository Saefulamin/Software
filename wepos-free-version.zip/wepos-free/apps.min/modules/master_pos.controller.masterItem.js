/**
 * Table of contents: 
 * masterItem.js
 * Generated: 2016-09-09 02:17:28
 */


/* Filename: masterItem.js */
/**
 * @class ExtApp.modules.master_pos.controller.masterItem
 * @extends ExtApp.core.Module
 * @author Angga Nugraha
 * @email angga.nugraha@gmail.com
 * @date Sat July 19 17:09:09 CDT 2014
 *
 * Description
 * Master masterItem
 *
 **/

Ext.define('ExtApp.modules.master_pos.controller.masterItem', {
    extend: 'ExtApp.core.Module',
	id:'modules.master_pos.masterItem',
	isloadModuleStore: true,
	suspendIfLoadStore: true,
    init : function(){
        this.launcher = {
            text: 'Items',
            iconCls:'icon-grid'
        };
    },	
	useHelper: [
	],
	ModuleStore: {
		'master_pos': [
			{store_name:'store_masterItem', autoload: true},
			{store_name:'store_itemGroup', autoload: false},
			{store_name:'store_masterUnit', autoload: false},
			{store_name:'store_masterSupplier', autoload: false},
			{store_name:'store_itemCategory', autoload: false}
		]
	},
	ModuleModel: {
		'master_pos': [
			{model_name:'model_masterItem'},
			{model_name:'model_masterUnit'},
			{model_name:'model_masterSupplier'},
			{model_name:'model_itemCategory'}
		]
	},
    createWindow : function(me, winID, winFunc){
        
		var me = this;
		
		var win_func = 'openWindow';
		if(winFunc){
			win_func = winFunc;
		}
		
		var win_id = me.id;
		if(winID){
			win_id = me.id+'_'+winID;
			if(!winFunc){
				win_func = winID;
			}
		}
		
		//get desktop
		var desktop = me.app.getDesktop();
        var win = me.app.getDesktop().getWindow(win_id);
		
		//check window
        if(!win){
			me.app.createView('ExtApp.modules.master_pos.view.masterItem', me, win_func);			
		}else{
			me.app.desktop.restoreWindow(win);
		}
    },
	doClose: function(winVar){
		var me = this;
		var win = me.app.getDesktop().getWindow(winVar);
		if(win){
			win.doClose();
		}
	},
	
	save_masterItem: function(){
		var me = this;
		var form = Ext.getCmp('form_masterItem').getForm();
		
		if (form.isValid()) {
			form.submit({
				clientValidation : true,
				scope: me,
				url : serviceUrl,												
				method: 'POST',
				params:{
					module: 'master_pos',
					file: 'masterItem',
					action: 'save'
				},
				waitMsg : 'Saving Data...',
				success : function(mainObj, formObj) {
				
					me.doClose(me.id+'_add_masterItem');		
					Ext.getCmp('grid_masterItem').store.load();
					//ExtApp.Msg.info('Success!');
					
				},
				failure : function(mainObj, formObj) {
					var rsp = Ext.decode(formObj.response.responseText);
					if(!rsp.info){
						rsp.info = '';
					}
					ExtApp.Msg.error('Save Failed, '+rsp.info);
				}
			});
		}
	},
	
	deleteConfirm_masterItem : function() {
		var me = this;
		if(me.delete_data.id){
		
			//multi-delete
			var getSelection = Ext.getCmp('grid_masterItem').getSelectionModel().selected;
			var delete_var = {
				allID 	: [],
				allName	: ''
			};
			for(x in getSelection.items){
				delete_var.allID.push(getSelection.items[x].data.id);
				if(delete_var.allName == ''){
					delete_var.allName = getSelection.items[x].data.item_name;
				}else{
					delete_var.allName += ', '+getSelection.items[x].data.item_name;
				}
			}
		
			ExtApp.Msg.confirm('Delete: '+delete_var.allName+' ? <br/><br/><i>'+'<b>Notes:</b> Been used or related to other data</i>', false,
			function(btn){
			   if(btn=='yes'){
				    me.deleteAction_masterItem(delete_var); 
			   }else{
					return false;  							 
			   }
			});
		}else{
			ExtApp.Msg.info("Please choose data!");
		}
	},

	deleteAction_masterItem : function(delete_var) {
		var me = this;
		if(!delete_var.allID){
			ExtApp.Msg.info("Data undefined!");
			return;
		}
				
		//update progress
		me.app.updateLoadingBox('Delete Items', 'Delete: '+delete_var.allName, ' Deleting...', true);
		me.app.LoadingBox.show();
		
		Ext.Ajax.request({
			waitMsg: 'Deleting ...',
			url : serviceUrl,												
			method: 'POST',
			params:{
				module: 'master_pos',
				file: 'masterItem',
				action: 'delete',
				id: Ext.JSON.encode(delete_var.allID)
			},
			success:function(response,options){
				var rsp = Ext.decode(response.responseText);
				if(rsp.success == false){
					ExtApp.Msg.warning(rsp.info);
				}

				Ext.getCmp('grid_masterItem').store.load();
				me.app.LoadingBox.hide();
			},
			failure:function(response,options){
				var rsp = Ext.decode(response.responseText);
				ExtApp.Msg.warning(rsp.info);
			}
		});
	},
	
	search_masterItem: function(is_reset){
		
		if(is_reset){
			Ext.getCmp('keywords_masterItem').setValue('');
		}
		
		var keywords = Ext.getCmp('keywords_masterItem').getValue();
		var store_masterItem = Ext.getCmp('grid_masterItem').store;
				
		store_masterItem.proxy.extraParams.keywords = keywords;
		store_masterItem.load();
	}
	
});