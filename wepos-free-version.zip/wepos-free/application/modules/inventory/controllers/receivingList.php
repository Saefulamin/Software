<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class ReceivingList extends MY_Controller {
	
	public $table;
		
	function __construct()
	{
		parent::__construct();
		$this->prefix = config_item('db_prefix2');
		$this->load->model('model_receivinglist', 'm');
		$this->load->model('model_receivedetail', 'm2');
		$this->load->model('model_purchaseorderdetail', 'm3');
		$this->load->model('model_purchaseorder', 'm4');
		$this->load->model('model_stock', 'stock');
		$this->load->model('model_account_payable', 'account_payable');
	}
	
	//important for service load
	function services_model_loader(){
		$this->prefix = config_item('db_prefix2');
		$dt_model = array( 
			'm' => '../../inventory/models/model_receivinglist',
			'm2' => '../../inventory/models/model_receivedetail',
			'm3' => '../../purchase/models/model_purchaseorderdetail',
			'm4' => '../../purchase/models/model_purchaseorder',
			'stock' => '../../inventory/models/model_stock',
			'account_payable' => '../../account_payable/models/model_account_payable'
		);
		return $dt_model;
	}

	public function gridData()
	{
		$this->table = $this->prefix.'receiving';
		
		//receive_status_text
		$sortAlias = array(
			'receive_status_text' => 'a.receive_status'
		);		
		
		// Default Parameter
		$params = array(
			'fields'		=> 'a.*, b.po_number, c.supplier_name, d.storehouse_name',
			'primary_key'	=> 'a.id',
			'table'			=> $this->table.' as a',
			'join'			=> array(
									'many', 
									array( 
										array($this->prefix.'po as b','a.po_id = b.id','LEFT'),
										array($this->prefix.'supplier as c','a.supplier_id = c.id','LEFT'),
										array($this->prefix.'storehouse as d','a.storehouse_id = d.id','LEFT')
									) 
								),
			'where'			=> array('a.is_deleted' => 0),
			'order'			=> array('a.id' => 'DESC'),
			'sort_alias'	=> $sortAlias,
			'single'		=> false,
			'output'		=> 'array' //array, object, json
		);
		
		//DROPDOWN & SEARCHING
		$is_dropdown = $this->input->post('is_dropdown');
		$searching = $this->input->post('query');
		$receive_id = $this->input->post('receive_id');
		$not_cancel = $this->input->post('not_cancel');
		$skip_date = $this->input->post('skip_date');
		
		//FILTER
		$date_from = $this->input->post('date_from');
		$date_till = $this->input->post('date_till');
		$keywords = $this->input->post('keywords');
		if(!empty($keywords)){
			$searching = $keywords;
		}
		
		if($skip_date == true){
		
		}else{
		
			if(empty($date_from) AND empty($date_till)){
				$date_from = date('Y-m-d');
				$date_till = date('Y-m-d');
			}
			
			if(!empty($date_from) OR !empty($date_till)){
			
				if(empty($date_from)){ $date_from = date('Y-m-d'); }
				if(empty($date_till)){ $date_till = date('Y-m-td'); }
				
				$mktime_dari = strtotime($date_from);
				$mktime_sampai = strtotime($date_till);
							
				$qdate_from = date("Y-m-d",strtotime($date_from));
				$qdate_till = date("Y-m-d",strtotime($date_till));
				
				$params['where'][] = "(a.receive_date >= '".$qdate_from."' AND a.receive_date <= '".$qdate_till."')";
						
			}
		}
		
		if(!empty($is_dropdown)){
			$params['order'] = array('b.receive_number' => 'ASC');
		}
		if(!empty($searching)){
			$params['where'][] = "(a.receive_number LIKE '%".$searching."%' OR b.po_number LIKE '%".$searching."%' OR c.supplier_name LIKE '%".$searching."%')";
		}
		if(!empty($receive_id)){
			$params['where'] = array('a.id' => $receive_id);
		}
		
		//get data -> data, totalCount
		$get_data = $this->m->find_all($params);
		  		
  		$newData = array();
		
		if(!empty($get_data['data'])){
			foreach ($get_data['data'] as $s){
				
				if($s['receive_status'] == 'cancel'){
					$s['receive_status_text'] = '<span style="color:red;">Cancel</span>';
				}else
				if($s['receive_status'] == 'done'){
					$s['receive_status_text'] = '<span style="color:green;">Done</span>';
				}else{
					$s['receive_status_text'] = '<span style="color:blue;">Progress</span>';
				}
				
				//$s['total_price_text'] = 'Rp '.priceFormat($s['total_price']);
				
				array_push($newData, $s);
			}
		}
		
		$get_data['data'] = $newData;
		
      	die(json_encode($get_data));
	}
	
	public function gridDataDetail($get_receive_id = '', $direct = 0)
	{
		
		$this->table = $this->prefix.'receive_detail';
		$this->table_receiving = $this->prefix.'receiving';
		$this->table3 = $this->prefix.'po';
		$this->table4 = $this->prefix.'po_detail';
		$session_client_id = $this->session->userdata('client_id');
				
		if(empty($session_client_id)){
			die(json_encode(array('data' => array(), 'totalCount' => 0)));
		}
		
		// Default Parameter
		$params = array(
			'fields'		=> "a.*, a2.receive_status, b.id as item_id_real, b.item_name, b.item_price, b.item_image, c.unit_name, a2.receive_number",
			'primary_key'	=> 'a.id',
			'table'			=> $this->table.' as a',
			'join'			=> array(
									'many', 
									array( 
										array($this->prefix.'receiving as a2','a.receive_id = a2.id','LEFT'),
										array($this->prefix.'supplier_item as b2','b2.id = a.supplier_item_id','LEFT'),
										array($this->prefix.'items as b','a.item_id = b.id','LEFT'),
										array($this->prefix.'unit as c','a.unit_id = c.id','LEFT')
									) 
								),
			'order'			=> array('a.id' => 'ASC'),
			'single'		=> false,
			'output'		=> 'array' //array, object, json
		);
		
		//DROPDOWN & SEARCHING
		$is_dropdown = $this->input->post('is_dropdown');
		$searching = $this->input->post('query');
		$receive_id = $this->input->post('receive_id');
		
		if(!empty($is_dropdown)){
			$params['order'] = array('b.item_name' => 'ASC');
		}
		if(!empty($searching)){
			$params['where'][] = "(b.item_name LIKE '%".$searching."%')";
		}
		if(!empty($receive_id)){
			$params['where'] = array('a.receive_id' => $receive_id);
		}
		
		if(!empty($get_receive_id)){
			$params['where'] = array('a.receive_id' => $get_receive_id);
		}
		
		//get data -> data, totalCount
		$get_data = $this->m2->find_all($params);
		  
		
		$newData = array();
		$all_po_det_id = array();
		$all_po_det_qty = array();
		
		if(!empty($get_data['data'])){
			foreach ($get_data['data'] as $s){
				$s['receive_det_purchase_show'] = 'Rp '.priceFormat($s['receive_det_purchase']);
				$s['receive_det_date'] = date('d-m-Y', strtotime($s['receive_det_date']));
				$s['receive_det_qty_before'] = $s['receive_det_qty'];

				if(!in_array($s['po_detail_id'], $all_po_det_id)){
					$all_po_det_id[] = $s['po_detail_id'];
					$all_po_det_qty[$s['po_detail_id']] = array();
				}
				
				array_push($newData, $s);
			}
		}
		
		$get_data['data'] = $newData;
		
		$recheck_po_detail = array();
		//PO DETAIL
		if(!empty($all_po_det_id)){
			$all_po_det_id_sql = implode(",", $all_po_det_id);
			$this->db->select("a.*");
			$this->db->from($this->table4." as a");
			$this->db->join($this->table3." as a2","a2.id = a.po_id");
			$this->db->where("a.id IN (".$all_po_det_id_sql.")");
			$this->db->where("a2.is_deleted", 0);
			$get_po_det = $this->db->get();
			if($get_po_det->num_rows() > 0){
				foreach($get_po_det->result() as $det_po){
					
					if($det_po->po_receive_qty > $det_po->po_detail_qty){
						//$det_po->po_receive_qty = $det_po->po_detail_qty;
						if(!in_array($det_po->id, $recheck_po_detail )){
							$recheck_po_detail[] = $det_po->id;
						}
					}
					
					$all_po_det_qty[$det_po->id] = array(
						'po_detail_qty'	=> $det_po->po_detail_qty,
						'po_receive_qty'	=> $det_po->po_receive_qty
					);
				}
			}
		}
		
		if(!empty($recheck_po_detail)){
			
			$all_po_det_rec_qty = array();
			
			$recheck_po_detail_txt = implode(",", $recheck_po_detail);
			$this->db->select("a.*");
			$this->db->from($this->table." as a");
			$this->db->join($this->table_receiving." as b","b.id = a.receive_id","LEFT");
			$this->db->where("b.is_deleted", 0);
			$this->db->where("b.receive_status", "done");
			$this->db->where("a.po_detail_id IN ($recheck_po_detail_txt)");
			$get_rec_det = $this->db->get();
			if($get_rec_det->num_rows() > 0){
				foreach($get_rec_det->result() as $det_rec){
					if(empty($all_po_det_rec_qty[$det_rec->po_detail_id])){
						$all_po_det_rec_qty[$det_rec->po_detail_id] = 0;
					}
					
					$all_po_det_rec_qty[$det_rec->po_detail_id] += $det_rec->receive_det_qty;
				}
			}
		}
		
		if(!empty($all_po_det_rec_qty)){
			$update_po_qty = array();
			foreach($all_po_det_rec_qty as $key => $dt){
				
				if(!empty($all_po_det_qty[$key])){
					$all_po_det_qty[$key]['po_receive_qty'] = $dt;
					
					$update_po_qty[] = array(
						'id'			=> $key,
						'po_receive_qty'=> $dt
					);
				}
				
			}
			
			if(!empty($update_po_qty)){
				$this->db->update_batch($this->table4, $update_po_qty, "id");
			}
			
		}
		
		//echo '<pre>';
		//print_r($recheck_po_detail);
		//print_r($all_po_det_qty);
		//die();
		
		if(!empty($get_data['data'])){
			$newData = array();
			foreach($get_data['data'] as $s){
				
				$s['po_detail_qty'] = 0;
				$s['po_receive_qty'] = 0;
				$s['po_detail_qty_sisa'] = 0;
				if(!empty($all_po_det_qty[$s['po_detail_id']])){
					$s['po_detail_qty'] = $all_po_det_qty[$s['po_detail_id']]['po_detail_qty'];
					
					/*
					if($s['receive_status'] == 'done'){
						$s['po_receive_qty'] = $all_po_det_qty[$s['po_detail_id']]['po_receive_qty'];
					}else{
						$s['po_receive_qty'] = $all_po_det_qty[$s['po_detail_id']]['po_receive_qty'] - $s['receive_det_qty'];
					}
					*/
					
					$s['po_receive_qty'] = $all_po_det_qty[$s['po_detail_id']]['po_receive_qty'];
					
					//echo '<pre>';
					//print_r($s);
		
				}
				
				$s['po_detail_qty_sisa'] = $s['po_detail_qty'] - $s['po_receive_qty'];
				
				array_push($newData, $s);
			}
			$get_data['data'] = $newData;
		}
		
		//die();
		
		if(!empty($direct)){
			return $get_data['data'];
		}
		
      	die(json_encode($get_data));
	}
	
	/*SERVICES*/
	public function save()
	{
		$this->table = $this->prefix.'receiving';	
		$this->table2 = $this->prefix.'receive_detail';			
		$this->table3 = $this->prefix.'po';	
		$this->table4 = $this->prefix.'po_detail';			
		$session_user = $this->session->userdata('user_username');
		
		if(empty($session_user)){
			$r = array('success' => false, 'info' => 'User Session Expired, Please Re-Login!');
			die(json_encode($r));
		}
		
		$supplier_id = $this->input->post('supplier_id');
		$receive_date = $this->input->post('receive_date');
		$receive_memo = $this->input->post('receive_memo');
		$po_id = $this->input->post('po_id');
		$total_price = $this->input->post('total_price');
		$receive_ship_to = $this->input->post('receive_ship_to');
		$receive_project = $this->input->post('receive_project');
		$receive_status = $this->input->post('receive_status');
		$storehouse_id = $this->input->post('storehouse_id');
		if(empty($receive_status)){
			$receive_status = 'progress';
		}
		
		if(empty($storehouse_id)){
			$storehouse_id = $this->stock->get_primary_storehouse();
		}
		
		if(empty($storehouse_id)){
			$r = array('success' => false, 'info' => 'No Primary Warehouse! Please Setup Warehouse'); 
			die(json_encode($r));
		}
		
		//receiveDetail
		$receiveDetail = $this->input->post('receiveDetail');
		$receiveDetail = json_decode($receiveDetail, true);
		$total_receive_item = 0;
		if(!empty($receiveDetail)){
			$total_item = count($receiveDetail);
			foreach($receiveDetail as $dtDet){
				$total_receive_item += $dtDet['receive_det_qty'];
			}
		}
		
		$get_receive_number = receivingList::generate_receive_number();
		
		if(empty($get_receive_number)){
			$r = array('success' => false);
			die(json_encode($r));
		}	
		
		$warning_update_stok = false;
			
		$r = '';
		if($this->input->post('form_type_receivingList', true) == 'add')
		{
			$date_now = date("Y-m-d");
			//CLOSING DATE
			$var_closing = array(
				'xdate'	=> $date_now,
				'xtipe'	=> 'purchasing'
			);
			$is_closing = is_closing($var_closing);
			if($is_closing){
				$r = array('success' => false, 'info' => 'Purchasing & Receiving Date Been Closed!'); 
				die(json_encode($r));
			}
			
			$var = array(
				'fields'	=>	array(
				    'receive_number'  	=> 	$get_receive_number,
				    'supplier_id'  	=> 	$supplier_id,
				    'storehouse_id'  	=> 	$storehouse_id,
				    'receive_date'  => 	$receive_date,
				    'receive_memo'  => 	$receive_memo,
				    'total_qty'  	=> 	0,
				    'total_price'  	=> $total_price,
				    'receive_status'  => $receive_status,
				    'po_id'  		=> 	$po_id,
				    'receive_project'  	=> 	$receive_project,
				    'receive_ship_to'  	=> 	$receive_ship_to,
				    'created'		=>	date('Y-m-d H:i:s'),
					'createdby'		=>	$session_user,
					'updated'		=>	date('Y-m-d H:i:s'),
					'updatedby'		=>	$session_user
				),
				'table'		=>  $this->table
			);	
			
			$do_update_stok = false;
			$do_update_rollback_stok = false;
			$do_update_status_po = false;
			
			$update_stok = '';
			if($receive_status == 'done'){
				
				//cek warehouse
				$default_warehouse = $this->stock->get_primary_storehouse();
				if(empty($default_warehouse)){
					$r = array('success' => false, 'info' => 'No Primary Warehouse! Please Setup Warehouse'); 
					die(json_encode($r));
				}
				
				$do_update_stok = true;
				$do_update_status_po = true;
				
				$update_stok = 'update';
				
				if($total_receive_item == 0){
					$r = array('success' => false, 'info' => 'Total Receive item = 0!'); 
					die(json_encode($r));
				}
				
				//check if PO status not done!
				$this->db->from($this->table3);
				$this->db->where("id = '".$po_id."'");
				$this->db->where("po_status = 'done'");
				$get_stat_po = $this->db->get();	
				if($get_stat_po->num_rows() > 0){
					$r = array('success' => false, 'info' => 'Cannot Update Receiving to Done!<br/>Please Check PO Status.. all item been received!'); 
					die(json_encode($r));
				}
				
				if($receive_date != date("Y-m-d")){
					$warning_update_stok = true;
				}
				
			}
			
			
			//SAVE
			$insert_id = false;
			$this->lib_trans->begin();
			$save_data = $this->m->add($var);
			$insert_id = $this->m->get_insert_id();
			$this->lib_trans->commit();			
			if($save_data)
			{  
				$id = $insert_id;
				
				
				/*
				$r = array('success' => true, 'id' => $insert_id, 'receive_number'	=> '-', 'det_info' => array());
				$q_det = $this->m2->receiveDetail($receiveDetail, $insert_id, $update_stok);
				if(!empty($q_det['dtReceive']['receive_number'])){
					$r['receive_number'] = $q_det['dtReceive']['receive_number'];
				}
				$r['det_info'] = $q_det;
				
				
				if(!empty($q_det['update_stock'])){
					
					$post_params = array(
						'storehouse_item'	=> $q_det['update_stock']
					);
					
					$updateStock = $this->stock->update_stock_rekap($post_params);
					
				}
				
				
				$updatePO = $this->m4->update_status_PO($po_id);
				*/
				
				
			}
      		
		}else
		if($this->input->post('form_type_receivingList', true) == 'edit'){
			
			
			$var = array('fields'	=>	array(
				    //'supplier_id'  	=> 	$supplier_id,
				    'storehouse_id'  => 	$storehouse_id,
				    'receive_date'  => 	$receive_date,
				    'receive_memo'  => 	$receive_memo,
				    'total_price'  	=> $total_price,
					'receive_status'  => $receive_status,
				    'receive_project'  	=> 	$receive_project,
				    'receive_ship_to'  	=> 	$receive_ship_to,
					'updated'		=>	date('Y-m-d H:i:s'),
					'updatedby'		=>	$session_user
				),
				'table'			=>  $this->table,
				'primary_key'	=>  'id'
			);
			
			//UPDATE
			$id = $this->input->post('id', true);
			
			
			$do_update_stok = false;
			$do_update_rollback_stok = false;
			$do_update_status_po = false;
			
			//CEK OLD DATA
			$this->db->from($this->table);
			$this->db->where("id = '".$id."'");
			$get_dt = $this->db->get();	
			if($get_dt->num_rows() > 0){
				$old_data = $get_dt->row_array();
			}	
			
			//CLOSING DATE
			$var_closing = array(
				'xdate'	=> $old_data['receive_date'],
				'xtipe'	=> 'purchasing'
			);
			$is_closing = is_closing($var_closing);
			if($is_closing){
				$r = array('success' => false, 'info' => 'Purchasing & Receiving Date Been Closed!'); 
				die(json_encode($r));
			}
			
			
			if($old_data['receive_status'] == 'progress' AND $receive_status == 'done'){
				
				
				//cek warehouse
				$default_warehouse = $this->stock->get_primary_storehouse();
				if(empty($default_warehouse)){
					$r = array('success' => false, 'info' => 'No Primary Warehouse! Please Setup Warehouse'); 
					die(json_encode($r));
				}
				
				$do_update_stok = true;
				$do_update_status_po = true;
				
				if($total_receive_item == 0){
					$r = array('success' => false, 'info' => 'Total Receive item = 0!'); 
					die(json_encode($r));
				}
				
				//check if PO status not done!
				$this->db->from($this->table3);
				$this->db->where("id = '".$po_id."'");
				$this->db->where("po_status = 'done'");
				$get_stat_po = $this->db->get();	
				if($get_stat_po->num_rows() > 0){
					$r = array('success' => false, 'info' => 'Cannot Update Receiving to Done!<br/>Please Check PO Status.. all item been received!'); 
					die(json_encode($r));
				}	
				
				if($receive_date != date("Y-m-d")){
					$warning_update_stok = true;
				}
				
			}
			
			if($old_data['receive_status'] == 'done' AND $receive_status == 'progress'){
				$do_update_rollback_stok = true;
				$do_update_status_po = true;
				
				if($receive_date != date("Y-m-d")){
					$warning_update_stok = true;
				}
			}
			
			$this->lib_trans->begin();
			$save_data = $this->m->save($var, $id);
			$this->lib_trans->commit();
			
			
		}
		
		if($save_data)
		{  
	
			$update_stok = '';
			if($do_update_stok){
				$r['info'] = 'Update Stok';
				$update_stok = 'update';
			}
			
			if($do_update_rollback_stok){
				$r['info'] = 'Re-Update Stok';
				$update_stok = 'rollback';
			}
			
			$r = array('success' => true, 'id' => $id);
			
			//from add
			if($this->input->post('form_type_receivingList', true) == 'add')
			{
				$q_det = $this->m2->receiveDetail($receiveDetail, $id);
				
				if($receive_status == 'done'){
					//get/update ID -> $usageItemDetail
					$item_id_prod = array();
					$this->db->from($this->prefix.'receive_detail');
					$this->db->where("receive_id", $id);
					$get_det = $this->db->get();
					if($get_det->num_rows() > 0){
						foreach($get_det->result_array() as $dt){
							$item_id_prod[$dt['item_id']] = $dt['id'];
						}
					}
					
					$update_stok = 'update_add';
					
					$receiveDetail_BU = $receiveDetail;
					$receiveDetail = array();
					foreach($receiveDetail_BU as $dtD){
						
						if(!empty($item_id_prod[$dtD['item_id']])){
							$dtD['id'] = $item_id_prod[$dtD['item_id']];
							$receiveDetail[] = $dtD;
						}
						
					}
					
					$r['receiveDetail_done'] = $receiveDetail;
				}
			}
				
			$q_det = $this->m2->receiveDetail($receiveDetail, $id, $update_stok);
			if($q_det == false){
				$r = array('success' => false, 'info' => 'Input Receiving Failed!'); 
				die(json_encode($r));
			}
			
			$r['det_info'] = $q_det;
			
			if($warning_update_stok){
				$r['is_warning'] = 1;
				$r['info'] = 'Stock Been Changed (Realtime)<br/>Please Re-Generate/Fix Stock Transaction on List Stock Module!<br/>Re-generate/fix from: '.$receive_date;
			}
			
			if(!empty($q_det['dtReceive']['receive_number'])){
				$r['receive_number'] = $q_det['dtReceive']['receive_number'];
			}
			
			if(!empty($q_det['update_stock'])){
				
				$post_params = array(
					'storehouse_item'	=> $q_det['update_stock']
				);
				
				$updateStock = $this->stock->update_stock_rekap($post_params);
				
			}
			
			$updatePO = $this->m4->update_status_PO($po_id);
			$updateAP = $this->account_payable->set_account_payable_PO($po_id);
			//$r['success'] = false;
		}  
		else
		{  
			$r = array('success' => false);
		}
		
		die(json_encode(($r==null or $r=='')? array('success'=>false) : $r));
	}
	
	/* public function saveDetail(){
		$this->table = $this->prefix.'receive_detail';				
		
		$session_user = $this->session->userdata('user_username');
		$session_client_id = $this->session->userdata('client_id');
		
		$id = $this->input->post('id');
		$receive_id = $this->input->post('receive_id');
		$receive_number = $this->input->post('receive_number');
		$item_id = $this->input->post('item_id');
		$unit_id = $this->input->post('unit_id');
		$receive_det_qty = $this->input->post('receive_det_qty');
		$receive_det_qty_before = $this->input->post('receive_det_qty_before');
		$receive_det_date = $this->input->post('receive_det_date');
		
		//empty($receive_det_qty) OR
		if(empty($receive_id) OR empty($item_id) OR empty($session_client_id)){
			$r = array('success' => false, 'info' => 'Save Detail Failed!');
			die(json_encode($r));
		}		

		$var = array('fields'	=>	array(
				'receive_det_qty' => $receive_det_qty,
				'receive_det_date'	 => $receive_det_date,
			),
			'table'			=>  $this->table,
			'primary_key'	=>  'id'
		);
		
		//ADD/Edit		
		$this->lib_trans->begin();
			if(!empty($id)){
				$edit = $this->m2->save($var, $id);
			}
		$this->lib_trans->commit();
		
		if($edit AND ($receive_det_qty_before != $receive_det_qty))
		{  
			$this->lib_trans->begin();
			
				$total_qty = receivingList::get_total_qty($receive_id);
				$total_price = receivingList::get_total_price($receive_id);
				//UPDATE Total Qty
				$var2 = array('fields'	=>	array(
						'total_qty'  => $total_qty,
						'total_price'  => $total_price
					),
					'table'			=>  $this->prefix.'receiving',
					'primary_key'	=>  'id'
				);
				$update = $this->m->save($var2, $receive_id);
				
				//Get Current Stock
				$this->db->select("id, trx_qty")->from($this->prefix."stock");
				$this->db->where("trx_ref_det_id", $id);
				$this->db->where("trx_ref_data", $receive_number);
				$this->db->where("item_id", $item_id);
				$q_stock = $this->db->get();
				$dt_stock = $q_stock->row();
				$current_stock_qty = $dt_stock->trx_qty;
				$current_stock_id = $dt_stock->id;
				
				//UPDATE New QTY Stock
				$var3 = array('fields'	=>	array(
						'trx_qty'  => $receive_det_qty
					),
					'table'			=>  $this->prefix.'stock',
					'primary_key'	=>  'id'
				);
				$this->m->save($var3, $current_stock_id);
								
				//UPDATE last available stock Items
				//Get Last QTY Stock 
				$this->db->select("total_qty_stok")->from($this->prefix."items")->where("id", $item_id);
				$q_items = $this->db->get();
				$dt_items = $q_items->row();
				$last_stock = $dt_items->total_qty_stok;
				
				if($current_stock_qty > $receive_det_qty){
					$new_stock = $last_stock - ($current_stock_qty - $receive_det_qty);
				}else
				if($current_stock_qty < $receive_det_qty){
					$new_stock = $last_stock + ($receive_det_qty - $current_stock_qty);
				}else{
					$new_stock = $last_stock;
				}
				
				//UPDATE Last QTY Items
				$var4 = array('fields'	=>	array(
						'total_qty_stok'  => $new_stock
					),
					'table'			=>  $this->prefix.'items',
					'primary_key'	=>  'id'
				);
				$this->m->save($var4, $item_id);
				
				
				$r = array('success' => true, 'item_id' => $item_id, 'total_qty' => $total_qty);
				
			$this->lib_trans->commit();
		}  
		else
		{  
			$r = array('success' => false, 'info' => 'Save Detail Failed!');
		}
		
		die(json_encode(($r==null or $r=='')? array('success'=>false) : $r));
	} */
		
	public function delete()
	{
		
		$this->table = $this->prefix.'receiving';
		$this->table2 = $this->prefix.'receive_detail';
		
		$get_id = $this->input->post('id', true);		
		$id = json_decode($get_id, true);
		//old data id
		$sql_Id = $id;
		if(is_array($id)){
			$sql_Id = implode("','", $id);
		}
		
		//Get Receive Data
		$this->db->select('*');
		$this->db->from($this->table);
		$this->db->where("id IN ('".$sql_Id."')");
		$get_receive = $this->db->get();
		
		//Get Receive Detail
		$this->db->select('*');
		$this->db->from($this->table2);
		$this->db->where("receive_id IN ('".$sql_Id."')");
		$get_receive_detail = $this->db->get();
		
		
		//delete data
		$update_data = array(
			'receive_status'	=> 'cancel',
			'is_deleted'=> 1
		);
		
		$this->db->where("id IN ('".$sql_Id."')");
		$q = $this->db->update($this->table, $update_data);
		
		$r = '';
		if($q)  
        {  
            $r = array('success' => true); 
			
			//delete detail too
			//$this->db->where("receive_id IN ('".$sql_Id."')");
			//$this->db->delete($this->table2);
			
			$this->lib_trans->begin();
				//UPDATE PO Status
				foreach($get_receive->result() as $row){
					$var4 = array('fields'	=>	array(
							'po_status'  => 'progress'
						),
						'table'			=>  $this->prefix.'po',
						'primary_key'	=>  'id'
					);
					$update = $this->m4->save($var4, $row->po_id);					
				}
				
				//UPDATE Stock
				$dtUpdate_Stock = array();
				$dtUpdate_Items = array();
				foreach($get_receive_detail->result_array() as $dt){
				
					$dtUpdate_Stock[] = array(
						"item_id" => $dt['item_id'],
						"trx_ref_det_id" => $dt['id'],
						"is_active" => "0",
					);
					
					//Get Stock Before
					$this->db->select("total_qty_stok")->from($this->prefix."items")->where("id", $dt['item_id']);
					$q_items = $this->db->get();
					$dt_items = $q_items->row();
					$current_stock = $dt_items->total_qty_stok;
				
					$dtUpdate_Items[] = array(
						"id" => $dt['item_id'],
						"total_qty_stok" => $current_stock - $dt['receive_det_qty']
					);
										
				}				
				
				//UPDATE BATCH total Stock
				if(!empty($dtUpdate_Stock)){
					$this->db->update_batch($this->prefix."stock", $dtUpdate_Stock, "trx_ref_det_id");
				}
				
				//UPDATE BATCH total Items
				if(!empty($dtUpdate_Items)){
					$this->db->update_batch($this->prefix."items", $dtUpdate_Items, "id");
				}
				
			$this->lib_trans->commit();
			
        }  
        else
        {  
            $r = array('success' => false, 'info' => 'Delete Receiving List Failed!'); 
        }
		die(json_encode($r));
	}
	
	public function deleteDetail()
	{
		
		$this->table = $this->prefix.'receive_detail';
		
		$get_id = $this->input->post('id', true);		
		$id = json_decode($get_id, true);
		//old data id
		$sql_Id = $id;
		if(is_array($id)){
			$sql_Id = implode("','", $id);
		}
		//Get receive_id
		$this->db->select('receive_id');
		$this->db->from($this->table);
		$this->db->where("id IN ('".$sql_Id."')");
		$get_data = $this->db->get();
		$data_receive_id = $get_data->row();
		
		//delete data
		$this->db->where("id IN ('".$sql_Id."')");
		$q = $this->db->delete($this->table);
		
		$r = '';
		if($q)  
        {  
			$total_price = receivingList::get_total_price($data_receive_id->receive_id);
            $r = array('success' => true, 'total_price' => $total_price); 
        }  
        else
        {  
            $r = array('success' => false, 'info' => 'Delete Receiving List Detail Failed!'); 
        }
		die(json_encode($r));
	}
	
	public function get_total_qty($receive_id){
		$this->table = $this->prefix.'receive_detail';	
		
		$this->db->select('SUM(receive_det_qty) as total_qty');
		$this->db->from($this->table);
		$this->db->where('receive_id', $receive_id);
		$get_tot = $this->db->get();
		
		$total_qty = 0;
		if($get_tot->num_rows() > 0){
			$data_po = $get_tot->row();
			$total_qty = $data_po->total_qty;
		}
		
		return $total_qty;
	}
	
	public function get_total_price($receive_id){
		$this->table = $this->prefix.'receive_detail';	
		
		$this->db->select('SUM(receive_det_qty * receive_det_purchase) as total_price');
		$this->db->from($this->table);
		$this->db->where('receive_id', $receive_id);
		$get_tot = $this->db->get();
		
		$total_price = 0;
		if($get_tot->num_rows() > 0){
			$data_po = $get_tot->row();
			$total_price = $data_po->total_price;
		}
		
		return $total_price;
	}
	
	public function generate_receive_number(){
		$this->table = $this->prefix.'receiving';						
		
		$getDate = date("ym");
		
		$this->db->from($this->table);
		$this->db->where("receive_number LIKE 'RL".$getDate."%'");
		$this->db->order_by('id', 'DESC');
		$get_last = $this->db->get();
		if($get_last->num_rows() > 0){
			$data_rl = $get_last->row();
			$receive_number = str_replace("RL".$getDate,"", $data_rl->receive_number);
			$receive_number = str_replace("RL","", $receive_number);
						
			$receive_number = (int) $receive_number;			
		}else{
			$receive_number = 0;
		}
		
		$receive_number++;
		$length_no = strlen($receive_number);
		switch ($length_no) {
			case 3:
				$receive_number = $receive_number;
				break;
			case 2:
				$receive_number = '0'.$receive_number;
				break;
			case 1:
				$receive_number = '00'.$receive_number;
				break;
			default:
				$receive_number = '00'.$receive_number;
				break;
		}
				
		return 'RL'.$getDate.$receive_number;				
	}

	public function printReceiving(){
		
		$this->table  = $this->prefix.'receiving'; 
		$this->table2 = $this->prefix.'receive_detail';
		$this->table_client  = config_item('db_prefix').'clients';
		
		$session_user = $this->session->userdata('user_username');					
		$user_fullname = $this->session->userdata('user_fullname');				
		$client_id = $this->session->userdata('client_id');								
		
		//get client
		$this->db->from($this->table_client);
		$this->db->where("id",$client_id);
		$get_client = $this->db->get();
		$dt_client = array();
		if($get_client->num_rows() > 0){
			$dt_client = $get_client->row_array();
		}
		
		if(empty($session_user)){
			die('User Session Expired, Please Re-Login!');
		}
		
		extract($_GET);
		
		$data_post = array(
			'do'	=> '',
			'receive_data'	=> array(),
			'receive_detail'	=> array(),
			'report_place_default'	=> '',
			'user_fullname'	=> $user_fullname,
			'client'	=> $dt_client
		);
		
		$get_opt = get_option_value(array('report_place_default'));
		if(!empty($get_opt['report_place_default'])){
			$data_post['report_place_default'] = $get_opt['report_place_default'];
		}
		
		if(empty($receive_id)){
			die('Receiving List Not Found!');
		}else{
			
			$this->db->select("a.*, b.supplier_name, c.po_number");
			$this->db->from($this->table." as a");
			$this->db->join($this->prefix."supplier as b","b.id = a.supplier_id","LEFT");
			$this->db->join($this->prefix."po as c","c.id = a.po_id","LEFT");
			$this->db->where("a.id = '".$receive_id."'");
			$get_dt = $this->db->get();
			if($get_dt->num_rows() > 0){
				$data_post['receive_data'] = $get_dt->row_array();
				
				//get detail
				$this->db->select("a.*, b.item_name, b.item_type, c.unit_code, c.unit_name");
				$this->db->from($this->table2." as a");
				$this->db->join($this->prefix."items as b","b.id = a.item_id","LEFT");
				$this->db->join($this->prefix."unit as c","c.id = a.unit_id","LEFT");
				$this->db->where("a.receive_id = '".$receive_id."'");
				$get_det = $this->db->get();
				if($get_det->num_rows() > 0){
					$data_post['receive_detail'] = $get_det->result_array();
				}
				
			}else{
				die('Receiving List Not Found!');
			}
		}
		
		//get all receive po_detail
		$all_po_det_id = array();
		if(!empty($data_post['receive_detail'])){
			foreach($data_post['receive_detail'] as $dtR){
				if(!in_array($dtR['po_detail_id'], $all_po_det_id)){
					$all_po_det_id[] = $dtR['po_detail_id'];
				}
			}
		}
		
		if(!empty($all_po_det_id)){
			$all_po_det_id_sql = implode(",", $all_po_det_id);
			$this->db->select("a.*");
			$this->db->from($this->prefix."receive_detail as a");
			$this->db->join($this->prefix."receiving as a2","a2.id = a.receive_id","LEFT");
			$this->db->where("po_detail_id IN (".$all_po_det_id_sql.")");
			$this->db->where("a2.is_deleted", 0);
			$get_rec_po_det = $this->db->get();
			if($get_rec_po_det->num_rows() > 0){
				foreach($get_rec_po_det->result() as $det_rec){
					if(empty($all_receive_po_det_qty[$det_rec->po_detail_id])){
						$all_receive_po_det_qty[$det_rec->po_detail_id] = 0;
					}
						
					$all_receive_po_det_qty[$det_rec->po_detail_id] += $det_rec->receive_det_qty;
				}
			}
		}
		
		$data_post['all_receive_po_det_qty'] = $all_receive_po_det_qty;
		
		//print_r($all_receive_po_det_qty);
		
		//DO-PRINT
		if(!empty($do)){
			$data_post['do'] = $do;
		}
		
		$this->load->view('../../inventory/views/printReceiving', $data_post);
		
	}
}