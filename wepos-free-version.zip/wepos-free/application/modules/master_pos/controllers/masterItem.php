<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MasterItem extends MY_Controller {
	
	public $table;
		
	function __construct()
	{
		parent::__construct();
		$this->prefix = config_item('db_prefix2');
		$this->load->model('model_masteritem', 'm');
	}
	
	//important for service load
	function services_model_loader(){
		$this->prefix = config_item('db_prefix2');
		$dt_model = array( 'm' => '../../master_pos/models/model_masteritem');
		return $dt_model;
	}

	public function gridData()
	{
		$this->table = $this->prefix.'items';
		$this->item_img_url = RESOURCES_URL.'items/thumb/';
		
		//is_active_text
		$sortAlias = array(
			'is_active_text' => 'is_active',
			'item_type_name' => 'item_type'
		);		
		
		// Default Parameter
		$params = array(
			'fields'		=> 'a.*, b.unit_name, c.supplier_name, d.item_category_name',
			'primary_key'	=> 'a.id',
			'table'			=> $this->table.' as a',
			'join'			=> array(
									'many', 
									array( 
										array($this->prefix.'unit as b','b.id = a.unit_id','LEFT'),
										array($this->prefix.'supplier as c','c.id = a.supplier_id','LEFT'),
										array($this->prefix.'item_category as d','d.id = a.category_id','LEFT')
									) 
								),
			'where'			=> array('a.is_deleted' => 0),
			'order'			=> array('a.id' => 'DESC'),
			'sort_alias'	=> $sortAlias,
			'single'		=> false,
			'output'		=> 'array' //array, object, json
		);
		
		//DROPDOWN & SEARCHING
		$is_dropdown = $this->input->post('is_dropdown');
		$searching = $this->input->post('query');
		$supplier_id = $this->input->post('supplier_id');
		$keywords = $this->input->post('keywords');
		$is_last_stock = $this->input->post('is_last_stock');
		$storehouse_id = $this->input->post('storehouse_id');
		
		if(!empty($keywords)){
			$searching = $keywords;
		}
		
		if(!empty($is_dropdown)){
			$params['order'] = array('item_name' => 'ASC');
			$params['where'][] = array('a.is_active' => 1);
		}
		if(!empty($searching)){
			$params['where'][] = "(item_name LIKE '%".$searching."%' OR c.supplier_name LIKE '%".$searching."%')";
		}
		if(!empty($supplier_id)){
			$params['where'][] = "a.supplier_id = ".$supplier_id."";
		}
		
		//get data -> data, totalCount
		$get_data = $this->m->find_all($params);
		  		
  		$newData = array();
		if(!empty($get_data['data'])){
			foreach ($get_data['data'] as $s){
				if(empty($s['item_image'])){
					$s['item_image'] = 'no-image.jpg';
				}
				$s['item_image_show'] = '<img src="'.$this->item_img_url.$s['item_image'].'" style="max-width:80px; max-height:60px;"/>';
				$s['item_image_src'] = $this->item_img_url.$s['item_image'];
				$s['is_active_text'] = ($s['is_active'] == '1') ? '<span style="color:green;">Active</span>':'<span style="color:red;">Inactive</span>';
				$s['item_price_show'] = 'Rp '.priceFormat($s['item_price']);
				$s['item_hpp_show'] = 'Rp '.priceFormat($s['item_hpp']);
				$s['last_in_show'] = 'Rp '.priceFormat($s['last_in']);
				
				if(empty($s['item_type'])){
					$s['item_type'] = 'main';
				}
				
				$s['item_type_name'] = 'Bahan Baku';
				if($s['item_type'] == 'support'){
					$s['item_type_name'] = 'Bahan Pendukung';
				}
				
				$s['total_qty_stok'] = 0;
				
				array_push($newData, $s);
			}
		}
		
		if(!empty($is_last_stock)){
			if(!empty($storehouse_id)){
				//check last stock - stock_rekap
				$all_item = array();
				$all_item_stock = array();
				$this->db->from($this->prefix.'stock_rekap');
				$this->db->where("trx_date", date("Y-m-d"));
				$this->db->where("storehouse_id", $storehouse_id);
				$get_stock = $this->db->get();
				if($get_stock->num_rows() > 0){
					foreach($get_stock->result() as $dt){
						
						if(!in_array($dt->item_id, $all_item)){
							$all_item[] = $dt->item_id;
							$all_item_stock[$dt->item_id] = $dt->total_stock;
						}
						
					}
				}
				
				//echo '<pre>';
				//print_r($all_item_stock);
				//die();
				
				$newData_old = $newData;
				$newData = array();
				foreach($newData_old as $dt){
					
					if(!empty($all_item_stock[$dt['id']])){
						$dt['total_qty_stok'] = $all_item_stock[$dt['id']];
					}
					
					$newData[] = $dt;
				}
				
			}
		}
		
		$get_data['data'] = $newData;
		
      	die(json_encode($get_data));
	}
	
	/*SERVICES*/
	public function save()
	{
		$this->table = $this->prefix.'items';							
		$session_user = $this->session->userdata('user_username');
				
		$item_name = $this->input->post('item_name');
		$item_desc = $this->input->post('item_desc');
		$item_price = $this->input->post('item_price');
		$unit_id = $this->input->post('unit_id');
		$category_id = $this->input->post('category_id');
		$supplier_id = $this->input->post('supplier_id');
		$item_image = $this->input->post('item_image');
		$item_type = $this->input->post('item_type');
		$item_hpp = $this->input->post('item_hpp');
		$item_manufacturer = '';//$this->input->post('item_manufacturer');
		
		/*CONTENT IMAGE UPLOAD SIZE*/		
		$this->item_img_url = RESOURCES_URL.'items/';		
		$this->item_img_path_big = RESOURCES_PATH.'items/big/';
		$this->item_img_path_thumb = RESOURCES_PATH.'items/thumb/';
		$this->item_img_path_tiny = RESOURCES_PATH.'items/tiny/';
		
		$big_size_width = 640;
		$big_size_height = 480;
		$thumb_size_width = 160;
		$thumb_size_height = 120;
		$tiny_size_width = 80;
		$tiny_size_height = 60;
		$is_upload_file = false;		
		if(!empty($_FILES['upload_image']['name'])){
						
			$config['upload_path'] = $this->item_img_path_big;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']	= '1024';

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload("upload_image"))
			{
				$data = $this->upload->display_errors();
				$r = array('success' => false, 'info' => $data );
				die(json_encode($r));
			}
			else
			{
				$is_upload_file = true;
				$data_upload_temp = $this->upload->data();
				$r = array('success' => true, 'info' => $data_upload_temp); 
			}
		}
		
		
		if(empty($item_name)){
			$r = array('success' => false);
			die(json_encode($r));
		}		
		
		$is_active = $this->input->post('is_active');
		if(empty($is_active)){
			$is_active = 0;
		}
			
		$r = '';
		if($this->input->post('form_type_masterItem', true) == 'add')
		{
			$var = array(
				'fields'	=>	array(
				    'item_name' => 	$item_name,
					'item_desc'	=>	$item_desc,
					'unit_id'	=>	$unit_id,
					'category_id'	=>	$category_id,
					'supplier_id'	=>	$supplier_id,
					'item_price'=>	$item_price,
					'item_hpp'	=>	$item_hpp,
					'item_type'	=>	$item_type,
					'item_manufacturer'	=>	$item_manufacturer,
					'created'		=>	date('Y-m-d H:i:s'),
					'createdby'		=>	$session_user,
					'updated'		=>	date('Y-m-d H:i:s'),
					'updatedby'		=>	$session_user,
					'is_active'	=>	$is_active
				),
				'table'		=>  $this->table
			);				
			
			
			if($is_upload_file){
				$get_file = do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_big, '', $big_size_width, $big_size_height, TRUE, 'height');
				$var['fields']['item_image'] = $get_file;
				
			}
			
			//SAVE
			$insert_id = false;
			$this->lib_trans->begin();
				$q = $this->m->add($var);
				$insert_id = $this->m->get_insert_id();
			$this->lib_trans->commit();			
			if($q)
			{  
				if($is_upload_file){					
					//thumb width 
					do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_thumb, '', $thumb_size_width);
					
					//tiny
					do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_tiny, '', $tiny_size_width, $tiny_size_height, TRUE, 'height');
				}
				
				$r = array('success' => true, 'id' => $insert_id); 				
			}  
			else
			{  
				if($is_upload_file){
					//unset upload file
					@unlink($this->item_img_path_big.$data_upload_temp['file_name']);
					
				}
				
				$r = array('success' => false);
			}
      		
		}else
		if($this->input->post('form_type_masterItem', true) == 'edit'){
			$var = array('fields'	=>	array(
				    'item_name' => 	$item_name,
					'item_desc'	=>	$item_desc,
					'item_price'=>	$item_price,
					'unit_id'	=>	$unit_id,
					'category_id'	=>	$category_id,
					'supplier_id'	=>	$supplier_id,
					'item_hpp'	=>	$item_hpp,
					'item_type'	=>	$item_type,
					//'item_manufacturer'	=>	$item_manufacturer,
					'updated'		=>	date('Y-m-d H:i:s'),
					'updatedby'		=>	$session_user,
					'is_active'		=>	$is_active
				),
				'table'			=>  $this->table,
				'primary_key'	=>  'id'
			);
						
			if($is_upload_file){
				$get_file = do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_big, '', $big_size_width, $big_size_height, TRUE, 'height');
				$var['fields']['item_image'] = $get_file;
			}
			
			//UPDATE
			$id = $this->input->post('id', true);
			$this->lib_trans->begin();
				$update = $this->m->save($var, $id);
			$this->lib_trans->commit();
			
			if($update)
			{  
				
				if($is_upload_file){					
					//thumb width 200pixel
					do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_thumb, '', $thumb_size_width);
					
					//tiny
					do_thumb($data_upload_temp, $this->item_img_path_big, $this->item_img_path_tiny, '', $tiny_size_width, $tiny_size_height, TRUE, 'height');
					
					//unset old file
					if(!empty($item_image) AND $item_image != 'no-image.jpg'){
						@unlink($this->item_img_path_big.$item_image);
						@unlink($this->item_img_path_thumb.$item_image);
						@unlink($this->item_img_path_tiny.$item_image);
					}
				}
				
				$r = array('success' => true, 'id' => $id);
			}  
			else
			{  
				if($is_upload_file){
					//unset upload file
					@unlink($this->item_img_path_big.$data_upload_temp['file_name']);					
				}
				
				$r = array('success' => false);
			}
		}
		
		die(json_encode(($r==null or $r=='')? array('success'=>false) : $r));
	}
	
	public function delete()
	{
		$this->table = $this->prefix.'items';
		$this->item_img_path_big = RESOURCES_PATH.'items/big/';
		$this->item_img_path_thumb = RESOURCES_PATH.'items/thumb/';
		$this->item_img_path_tiny = RESOURCES_PATH.'items/tiny/';
		
		$get_id = $this->input->post('id', true);		
		$id = json_decode($get_id, true);
		//old data id
		$sql_Id = $id;
		if(is_array($id)){
			$sql_Id = implode(',', $id);
		}
		
		//Delete
		$this->db->where("id IN (".$sql_Id.")");
		$get_items = $this->db->get($this->table);
		
		//$this->db->where("id IN (".$sql_Id.")");
		$data_update = array(
			"is_deleted" => 1
		);
		$q = $this->db->update($this->table,$data_update,"id IN (".$sql_Id.")");
		
		$r = '';
		if($q)  
        {  
			if($get_items->num_rows() > 0){
				
				foreach($get_items->result() as $dtP){
					if(!empty($dtP->item_image)){
						@unlink($this->item_img_path_big.$dtP->item_image);
						@unlink($this->item_img_path_thumb.$dtP->item_image);
						@unlink($this->item_img_path_tiny.$dtP->item_image);
					}
					
				}
				
			}
            $r = array('success' => true); 
        }  
        else
        {  
            $r = array('success' => false, 'info' => 'Delete Item Failed!'); 
        }
		die(json_encode($r));
	}
	
}