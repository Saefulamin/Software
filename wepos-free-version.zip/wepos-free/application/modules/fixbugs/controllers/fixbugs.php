<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fixbugs extends MY_Controller {
	
	function __construct()
	{
		parent::__construct();
	}

	public function index($call_tools = '')
	{
		if(empty($call_tools)){
			echo 'go away human??';
		}else{
			//check files
			//echo 'checking file.. '.MODULE_PATH.'fixbugs/models/'. $call_tools.'.php';
			if(file_exists(MODULE_PATH.'fixbugs/models/'. $call_tools.'.php')){
				echo ' CALLED TOOLS -OK ..<br/>';
				$this->load->model($call_tools, 'get_tools');
				$this->get_tools->generate();
			}else{
				echo ' wrong fixbugs execution!';
			}			
			
		}
		
	}
	
}
