<?php
class New_install extends DB_Model {
	
	public $table;
	
	function __construct()
	{
		parent::__construct();	
		$this->table = $this->prefix.'items';
	}
	
	function generate(){
		$this->prefix = config_item('db_prefix');
		$this->prefix2 = config_item('db_prefix2');
		$this->prefix3 = config_item('db_prefix3');
		
		echo '-- NEW INSTALLATION WEPOS --<br/>';
		
		echo '-- EMPTY Master Data --<br/>';
		//$this->db->query("TRUNCATE table ".$this->prefix2."payment_type");
		//$this->db->query("TRUNCATE table ".$this->prefix2."bank");
		$this->db->query("TRUNCATE table ".$this->prefix2."floorplan");
		$this->db->query("TRUNCATE table ".$this->prefix2."table");
		$this->db->query("TRUNCATE table ".$this->prefix2."table_inventory");
		$this->db->query("TRUNCATE table ".$this->prefix2."unit");
		$this->db->query("TRUNCATE table ".$this->prefix2."varian");
		$this->db->query("TRUNCATE table ".$this->prefix2."delivery");
		$this->db->query("TRUNCATE table ".$this->prefix2."divisi");
		echo '<br/>';		
		
		echo '-- EMPTY Menu/Product --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."product");
		$this->db->query("TRUNCATE table ".$this->prefix2."product_category");
		$this->db->query("TRUNCATE table ".$this->prefix2."product_package");
		$this->db->query("TRUNCATE table ".$this->prefix2."product_varian");
		echo '<br/>';		
		
		echo '-- EMPTY Billing --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."billing");
		$this->db->query("TRUNCATE table ".$this->prefix2."billing_additional_price");
		$this->db->query("TRUNCATE table ".$this->prefix2."billing_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."billing_detail_split");
		$this->db->query("TRUNCATE table ".$this->prefix2."billing_downpayment");
		$this->db->query("TRUNCATE table ".$this->prefix2."open_close_shift");
		echo '<br/>';		
		
		echo '-- EMPTY discount --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."discount");
		$this->db->query("TRUNCATE table ".$this->prefix2."discount_product");
		echo '<br/>';		
		
		echo '-- EMPTY Purchasing --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."po");
		$this->db->query("TRUNCATE table ".$this->prefix2."po_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."receiving");
		$this->db->query("TRUNCATE table ".$this->prefix2."receive_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."retur");
		$this->db->query("TRUNCATE table ".$this->prefix2."retur_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."ro");
		$this->db->query("TRUNCATE table ".$this->prefix2."ro_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."distribution");
		$this->db->query("TRUNCATE table ".$this->prefix2."distribution_detail");
		echo '<br/>';		
		
		echo '-- EMPTY Supplier --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."supplier");
		$this->db->query("TRUNCATE table ".$this->prefix2."supplier_item");
		echo '<br/>';		
		
		echo '-- EMPTY Item --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."items");
		$this->db->query("TRUNCATE table ".$this->prefix2."item_category");
		echo '<br/>';	
		
		echo '-- EMPTY Stock & Stock Opname --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."stock");
		$this->db->query("TRUNCATE table ".$this->prefix2."stock_opname");
		$this->db->query("TRUNCATE table ".$this->prefix2."stock_opname_detail");
		$this->db->query("TRUNCATE table ".$this->prefix2."stock_rekap");
		$this->db->query("TRUNCATE table ".$this->prefix2."stock_unit");
		echo '<br/>';		
		
		
		echo '-- EMPTY LOG --<br/>';
		$this->db->query("TRUNCATE table ".$this->prefix2."billing_log");
		$this->db->query("TRUNCATE table ".$this->prefix."supervisor_log");
		echo '<br/>';		
		
		
		echo '-- NEW INSTALLATION DONE --<br/>';
	}

} 