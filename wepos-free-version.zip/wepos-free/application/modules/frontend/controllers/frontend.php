<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Frontend extends MY_Controller {
	
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data['title']				=	'Option Menu | '.config_item('program_name');
		$data['meta_description'] 	=	config_item('program_name');
		$data['meta_keywords']		=	config_item('program_name');
		$data['meta_author']		=	config_item('program_author');
		$data['program_name']		=	config_item('program_name');
		$this->load->view('frontend', $data);
	}

	public function customer_display()
	{
		$data['title']				=	'CUSTOMER DISPLAY | '.config_item('program_name');
		$data['meta_description'] 	=	config_item('program_name');
		$data['meta_keywords']		=	config_item('program_name');
		$data['meta_author']		=	config_item('program_author');
		$data['program_name']		=	config_item('program_name');
		
		
		$this->load->view('customer_display', $data);
	}
	
	public function test_print($id = '')
	{		
		$this->prefix = 'pos_';
		$this->table = $this->prefix.'billing';
		$this->table2 = $this->prefix.'billing_detail';
		$session_user = $this->session->userdata('user_username');
		$id_user = $this->session->userdata('id_user');
		if(empty($session_user)){
			$r = array('success' => false, 'info' => 'User Session Expired, Please Re-Login!');
			echo json_encode($r);
			die();
		}
		
		if(empty($id)){
			die('SAMPLE ID KOSONG');
		}
		
		//cashier_receipt_layout
		$get_opt = get_option_value(array('cashier_receipt_layout','printer_cashier_default','printer_cashier_'.$id_user));
		
		$printer_cashier = $get_opt['printer_cashier_default'];
		if(!empty($get_opt['printer_cashier_'.$id_user])){
			$printer_cashier = $get_opt['printer_cashier_'.$id_user];
			
			if(strstr($printer_cashier, '\\')){
				$printer_cashier = "\\\\".$printer_cashier;
			}
			
		}		
		
		$cashier_receipt_layout = $get_opt['cashier_receipt_layout'];
		
		$billingData = array();
		$this->db->select('*, id as billing_id');
		$this->db->from($this->table);
		$this->db->where('id', $id);
		//$this->db->where('createdby', $session_user);
		$get_last = $this->db->get();
		if($get_last->num_rows() > 0){
			$billingData = $get_last->row();		
		}
		
		if(!empty($billingData)){
		
			$is_print_error = false;
			
			$this->db->select("a.*, a2.table_no, a2.billing_no,
							b.product_name, b.product_desc, b.product_type, b.product_image, 
							b.category_id, c.product_category_name");
			$this->db->from($this->table2.' as a');
			$this->db->join($this->prefix.'billing as a2','a2.id = a.billing_id','LEFT');
			$this->db->join($this->prefix.'product as b','b.id = a.product_id','LEFT');
			$this->db->join($this->prefix.'product_category as c','c.id = b.category_id','LEFT');
			$this->db->where('a.is_deleted', 0);
			$this->db->where("a.billing_id IN (".$id.")");
			
			$get_detail = $this->db->get();
	
			$order_data = "";	
			$subtotal = 0;
			if($get_detail->num_rows() > 0){

				$no = 1;
				foreach($get_detail->result() as $bil_det){					
					$order_total = $bil_det->order_qty * $bil_det->product_price;
					
					//trim prod name
					$max_text = 19;
					$all_text_array = array();
					$product_name = $bil_det->product_name;
					if(strlen($product_name) > $max_text){
						//skip on last space
						$explTxt = explode(" ",$bil_det->product_name);
						
						$no_exp = 1;
						$tot_txt = 0;
						$text_display = '';
						foreach($explTxt as $txt){
							$lnTxt = strlen($txt);
							$tot_txt += $lnTxt;
							
							if($tot_txt > 0){
								$tot_txt+=1; //space
							}
							
							if($tot_txt > $max_text){
								$all_text_array[] = $text_display;
								$tot_txt = 0;
								$text_display = $txt;
								
								//echo $text_display.' '.$tot_txt.'<br/>';
								
							}else{
							
								if(empty($text_display)){
									$text_display = $txt;
								}else{
									$text_display .= ' '.$txt;										
								}
								
								//echo $text_display.' '.$tot_txt.'<br/>';
								
							}
							
							if(count($explTxt) == $no_exp){
								$all_text_array[] = $text_display;
							}
							
							$no_exp++;
						}
						
						if(empty($all_text_array[0])){
							$product_name = substr($product_name, 0, $max_text);
						}else{
							$product_name = $all_text_array[0];
						}
					}
											
					$product_price_show = printer_command_align_right('@'.$bil_det->product_price, 7);
					//$product_price_show = printer_command_align_right('@'.priceFormat($bil_det->product_price), 7);
					//$order_total_show = printer_command_align_right(priceFormat($order_total), 10);
					$order_total_show = printer_command_align_right($order_total, 9);
					
					$order_data .= "[align=0]".$bil_det->order_qty."[tab]".$product_name."[tab]".$product_price_show."[tab]".$order_total_show;
					
					//other text - continue 
					foreach($all_text_array as $no_dt => $product_name_extend){
					
						if($no_dt > 0){
							$order_data .= "\n"; 
							$order_data .= "[align=0] [tab]".$product_name_extend."[tab] [tab]";
						}
						
					}
					
					//echo '<pre>';
					//print_r($all_text_array);
			
					if($no < $get_detail->num_rows()){
						$order_data .= "\n";
					}
					
					$subtotal += $order_total;
					$no++;
				}				
			}
			
			$pajak = 10/100 * $subtotal;
			$pajak_show = printer_command_align_right(priceFormat($pajak), 9);
			$additional_total = "[tab]Pajak PB1[tab]".$pajak_show;
			$total = $subtotal + $pajak;
			
			$max_pembulatan = 100;
			$last2digit = substr($total,-2);
			$last2digit = intval($last2digit);
			$pembulatan = $max_pembulatan - $last2digit;
	
			if($last2digit == 100 OR $last2digit == 0){
				$pembulatan = 0;
			}
			
			$pembulatan_show = priceFormat(($pembulatan*-1));
			
			$grand_total = $total - $pembulatan;
			
			$cash = $billingData->total_paid;
			$return = $cash - $grand_total;
							
			$subtotal_show = printer_command_align_right(priceFormat($subtotal), 9);
			$total_show = printer_command_align_right(priceFormat($total), 9);
			$pembulatan_show = printer_command_align_right($pembulatan_show, 9);
			$grand_total_show = printer_command_align_right(priceFormat($grand_total), 9);
			$cash_show = printer_command_align_right(priceFormat($cash), 9);
			$return_show = printer_command_align_right(priceFormat($return), 9);
			
			$print_attr = array(
				"{date}"	=> date("d/m/Y"),
				"{user}"	=> $session_user,
				"{table_no}"	=> $billingData->table_no,
				"{billing_no}"	=> $billingData->billing_no,
				"{order_data}"	=> $order_data,
				"{subtotal}"	=> $subtotal_show,
				"{additional_total}" => $additional_total,
				"{total}"	=> $total_show,
				"{rounded}"	=> $pembulatan_show,
				"{grand_total}"	=> $grand_total_show,
				"{cash}"	=> $cash_show,
				"{return}"	=> $return_show
			);
			
			$print_content = strtr($cashier_receipt_layout, $print_attr);
					
			$print_content = replace_to_printer_command($print_content);
						
			//DIRECT PRINT USING PHP - KITCHEN PRINTER			
			$ph = printer_open($printer_cashier);
			if($ph)
			{
				printer_start_doc($ph, "CASHIER - PAYMENT");
				printer_start_page($ph);
				printer_set_option($ph, PRINTER_MODE, "RAW");
				printer_write($ph, $print_content);
				printer_end_page($ph);
				printer_end_doc($ph);
				printer_close($ph);
			
			}else{
				$is_print_error = true;
			}
			
			if($is_print_error){
				die('Communication with Printer Failed!');
			}else{
				echo $print_content;
			}
			
		}else{
			die('Load Detail Failed, data not found!');
		}
		
	}
	
}
