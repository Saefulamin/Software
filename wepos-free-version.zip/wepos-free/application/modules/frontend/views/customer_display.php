<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="description" content="<?php echo $meta_description; ?>">
    <meta name="author" content="<?php echo $meta_author; ?>">
    <meta name="keywords" content="<?php echo $meta_keywords; ?>">

    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/themes/frontend/images/favicon.ico" />	
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/themes/frontend/js/jquery-1.9.0.min.js"></script>
	
	<script>
		var appUrl 		= "<?php echo site_url(); ?>";
		var programName	= "<?php echo config_item('program_name'); ?>";
		var copyright	= "<?php echo config_item('copyright'); ?>";
	</script>
	<script type="text/javascript">
	
		$(document).ready(function(e)
		{
			
			
		});
	
	</script>
    <title><?php echo $title; ?></title>
</head>
<body>
	<?php 
		//$ip_addr = $this->input->ip_address();
		$ip_addr = get_client_ip(); 
		//echo $ip_addr;
		
		if (!$this->input->valid_ip($ip_addr)){
			echo "Not a valid IP ".$ip_addr;
		}
		else
		{
			echo "Valid IP! = ".$ip_addr;
		}
		
	?>
	<div style="margin:10px auto; width:1000px; height:450px;">
		<div style="width:240px; float:left; padding:10px; border:1px solid #d8d8d8; height:450px;">CASHIER INFO</div>
		<div style="width:340px; float:left; padding:10px; border:1px solid #d8d8d8; height:450px;">CUSTOMER BILL INFO</div>
		<div style="width:340px; float:left; padding:10px; border:1px solid #d8d8d8; height:450px;">ADVERTISMENT</div>
		<div style="clear:both;"></div>
	</div>
</body>
</html>