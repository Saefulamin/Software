<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*General Info*/
$config['program_name']			=	'WePOS-Free';
$config['program_version']		=	'2.422';
$config['program_release']		=	'2015';
$config['program_name_short'] 	=	'WePOS-Free';
$config['copyright']			=	$config['program_name_short'].' v'.$config['program_version'].' &copy copyright '.$config['program_release'];
$config['client_name']			=	'WePOS-dev';
$config['program_author']		=	'WePOS-dev';

/*Common config*/
$config['db_prefix']	= 'apps_';
$config['db_prefix2']	= 'pos_';
$config['db_prefix3']	= 'acc_';

